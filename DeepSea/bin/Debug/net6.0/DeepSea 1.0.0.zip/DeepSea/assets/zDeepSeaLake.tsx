<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="zDeepSeaLake" tilewidth="16" tileheight="16" tilecount="288" columns="16">
 <image source="z_DeepSeaLake.png" width="256" height="288"/>
</tileset>
